double square(double val) {
	return val * val;
}
