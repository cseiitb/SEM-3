#ifndef _SQUARE_H_
#define _SQUARE_H_

double square(double val);

#endif
