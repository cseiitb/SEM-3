#include <square.h>
#include <iostream>
using namespace std;
int main() {
  int x;
  float y;
  cin >> x >> y;
  cout << square(x) + square(y) << endl;
}
