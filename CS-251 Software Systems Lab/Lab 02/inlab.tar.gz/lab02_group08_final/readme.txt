Group members
(Tejesh Raut,140050008),(Shrey Kumar,140050014),(Gangesh Gudmalwar, 140050058)

Group number: 08

We pledge on our honour that we have not given or received any unauthorized assistance on this assignment or any previous task


Individual percentages:
Tejesh: 100%
Shrey: 100%
Gangesh: 100%

Citations:

http://www.w3schools.com/
http://docs.mathjax.org/en/latest/start.html
https://help.ubuntu.com/community/MEncoder
